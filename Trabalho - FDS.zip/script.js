function mostrarMensagem() {
    const mensagem = "Porque Deus amou o mundo de tal maneira que deu o seu Filho unigênito, para que todo aquele que nele crê não pereça, mas tenha a vida eterna. (João 3:16)";
    document.getElementById("mensagem").innerText = mensagem;
}